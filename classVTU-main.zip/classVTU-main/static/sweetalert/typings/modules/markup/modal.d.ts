export declare const modalMarkup: string;
export default modalMarkup;
